export const DB_NAME = "hrdashboardassignment";
