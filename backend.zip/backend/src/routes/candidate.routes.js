import { Router } from "express";
import { addCandidate, updateCandidateStatus } from "../controllers/candidate.controller.js";
import { verifyJWT } from "../middlewares/auth.middleware.js";

const router = Router();

router.post("/add", verifyJWT, addCandidate);
router.post("/update/:id", verifyJWT, updateCandidateStatus)


export default router;