import { Router } from "express";
import {
  loginUser,
  logoutUser,
  refreshAccesToken,
  registerUser,
} from "../controllers/user.controller.js";
import { verifyJWT } from "../middlewares/auth.middleware.js";

const router = Router();

// Public routes
router.post("/register", registerUser);
router.post("/login", loginUser);

// Secured routes
router.post("/logout", verifyJWT, logoutUser);
router.post("/refresh-token", refreshAccesToken);

export default router;
