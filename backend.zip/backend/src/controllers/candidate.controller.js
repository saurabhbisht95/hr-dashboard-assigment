import Candidate from "../models/candidate.model.js";
import Employee from "../models/employee.model.js"
import { asyncHandler } from "../utils/asyncHandler.js";
import { ApiError } from "../utils/ApiError.js";
import { ApiResponse } from "../utils/ApiResponse.js";

// @desc Add a new candidate
// @route POST /api/candidates
// @access Private (attach auth middleware later)
const addCandidate = asyncHandler(async (req, res) => {
  const { fullname, email, phone, position, experience, resume, status } = req.body;

  // 1️⃣ Validation
 if (!fullname?.trim() || !email?.trim() || !phone?.trim() || 
    !position?.trim() || !resume?.trim() || experience == null) {
  throw new ApiError(400, "All fields are required");
}


  // 2️⃣ Check duplicate email
  const existingCandidate = await Candidate.findOne({ email });
  if (existingCandidate) {
    throw new ApiError(400, "Candidate with this email already exists");
  }

  // 3️⃣ Create candidate
  const candidate = await Candidate.create({
    fullname,
    email,
    phone,
    position,
    experience,
    resume,
    status, // schema default will be used if not passed
  });

  // 4️⃣ Verify candidate saved
  if (!candidate) {
    throw new ApiError(500, "Something went wrong while saving candidate");
  }

  // 5️⃣ Response
  return res
    .status(201)
    .json(new ApiResponse(201, candidate, "Candidate added successfully"));
});

//update candidate status

const updateCandidateStatus = asyncHandler(async (req, res) => {
    const { id } = req.params;

    const { status } = req.body;

    const candidate = await Candidate.findByIdAndUpdate(id, { status}, { new: true});

    if(!candidate){
        throw new ApiError(404, "Candidate not found");
    }

    if(status === "selected"){
        await Employee.create({
            fullname: candidate.fullname,
            email: candidate.email,
            phone: candidate.phone,
            department: candidate.position.split(" ")[0], // default or can be passed in request
            position: candidate.position.split(" ").slice(1).join(" ") || candidate.position,
            dateOfJoining: new Date() // current date
        })
    }

    return res
    .status(201)
    .json(new ApiResponse(201, Employee, "Employee added successfully"));
});

export { addCandidate, updateCandidateStatus };
